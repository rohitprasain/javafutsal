package dal;

public class Customer {
    public int id;
    public String name;
    public String contact;
    public String time;
    public Customer(int id, String name, String contact ,String time) {
        this.id = id;
        this.name = name;
        this.contact = contact;
        this.time = time;
    }
}
