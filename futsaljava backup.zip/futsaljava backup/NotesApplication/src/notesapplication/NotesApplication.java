package notesapplication;

import javax.swing.JFrame;

public class NotesApplication extends JFrame {

    public static void main(String[] args) {
               loginDialog1 login1 = new loginDialog1();
               login1.setVisible(true);  
        }
    }